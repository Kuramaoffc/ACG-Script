
--proc/system/registry: Registry API
--Written by Cosmin Apreutesei. Public Domain.

setfenv(1, require'winapi')

